<?php

namespace App\Imports;

use App\Models\StatusVideo;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class StatusVideoImport implements ToModel, WithHeadingRow, WithBatchInserts, WithChunkReading
{
    private $items;


    public function __construct()
    {
        $this->items = StatusVideo::pluck('name')->toArray();
    }
    public function model(array $row)
    {
        if (!in_array($row['video_status'], $this->items)) {
            array_push($this->items, $row['video_status']);
            return new StatusVideo([
                'name' => $row['video_status']
            ]);
        }
        return null;
    }

    // Inserciones por lotes
    public function batchSize(): int
    {
        return 1000;
    }

    // lectura de fragmentos
    public function chunkSize(): int
    {
        return 1000;
    }
}
