<?php

namespace App\Imports;

use App\Models\Category;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class CategoryImport implements ToModel, WithHeadingRow, WithBatchInserts, WithChunkReading
{
    private $categories;


    public function __construct()
    {
        $this->categories = Category::pluck('name')->toArray();
    }
    public function model(array $row)
    {
        if (!in_array($row['category'], $this->categories)) {
            array_push($this->categories, $row['category']);
            return new Category([
                'name' => $row['category']
            ]);
        }
        return null;
    }

    // Inserciones por lotes
    public function batchSize(): int
    {
        return 1000;
    }

    // lectura de fragmentos
    public function chunkSize(): int
    {
        return 1000;
    }
}
