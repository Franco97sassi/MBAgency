<?php

namespace App\Imports;

use App\Models\Group;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class GroupImport implements ToModel, WithHeadingRow, WithBatchInserts, WithChunkReading
{
    private $items;


    public function __construct()
    {
        $this->items = Group::pluck('name')->toArray();
    }
    public function model(array $row)
    {
        if (!in_array($row['group_name'], $this->items)) {
            array_push($this->items, $row['group_name']);
            return new Group([
                'name' => $row['group_name']
            ]);
        }
        return null;
    }

    // Inserciones por lotes
    public function batchSize(): int
    {
        return 1000;
    }

    // lectura de fragmentos
    public function chunkSize(): int
    {
        return 1000;
    }
}
