<?php

namespace App\Imports;

use App\Models\Story;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithBatchInserts;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class StoryImport implements ToModel, WithHeadingRow, WithBatchInserts, WithChunkReading
{
    private $items;


    public function __construct()
    {
        $this->items = Story::pluck('name')->toArray();
    }
    public function model(array $row)
    {
        if (!in_array($row['is_have_story'], $this->items)) {
            array_push($this->items, $row['is_have_story']);
            return new Story([
                'name' => $row['is_have_story']
            ]);
        }
        return null;
    }

    // Inserciones por lotes
    public function batchSize(): int
    {
        return 1000;
    }

    // lectura de fragmentos
    public function chunkSize(): int
    {
        return 1000;
    }
}
